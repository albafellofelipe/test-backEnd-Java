/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaClass.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javaClass.writer.FormWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author felipe
 */
public class MyServlet extends HttpServlet {

    public void service(HttpServletRequest req, HttpServletResponse resp) {
        try {
            //Pega os valores dos campos do cadastro
            String nome = req.getParameter("nome");
            String email = req.getParameter("email");
            String telefone = req.getParameter("telefone");
            String grupo = req.getParameter("grupo");
            //Chamada da função pra criar o arquivo
            FormWriter.writeOnFile(nome, email, telefone, grupo);
            //Redireciona para a listagem dos usuários
            req.getRequestDispatcher("lista.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
