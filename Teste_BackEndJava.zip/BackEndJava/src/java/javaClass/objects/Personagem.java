/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaClass.objects;

/**
 *
 * @author felipe
 */
public class Personagem {

    private String codinome;

    public Personagem() {
    }

    public Personagem(String nome) {
        this.codinome = nome;
    }

    public String getCodinome() {
        return codinome;
    }

    public void setCodinome(String codinome) {
        this.codinome = codinome;
    }

    @Override
    public String toString() {
        return this.codinome;
    }

}
