/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaClass.writer;

import java.io.FileWriter;
import java.io.PrintWriter;

/**
 *
 * @author felipe
 */
public class FormWriter {

    //Caminho do arquivo .txt
    private static final String path = ("form.txt");

    public static void writeOnFile(String nome, String email, String telefone, String grupo) {
        try {
            FileWriter writer = new FileWriter(path, true);
            PrintWriter pw = new PrintWriter(writer);
            //Função para escrever texto no arquivo
            pw.append(nome + " || " + email + " || " + telefone + " || " + grupo);
            pw.println();
            pw.close();
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
