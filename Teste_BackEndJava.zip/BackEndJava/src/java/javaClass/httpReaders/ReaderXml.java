package javaClass.httpReaders;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javaClass.objects.Personagem;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 *
 * @author felipe
 */
public class ReaderXml {

    public static void main(String[] args) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(new URL("https://raw.githubusercontent.com/uolhost/test-backEnd-Java/master/referencias/liga_da_justica.xml").openStream());

            doc.getDocumentElement().normalize();

            // Pega a primeira TAG
            NodeList nodeList = doc.getElementsByTagName("liga_da_justica");

            // Recupera segunda TAG (codnames)
            Element codinomes = (Element) nodeList.item(0);

            // Cria a lista das tags
            NodeList listaPersonagens = codinomes.getElementsByTagName("codinome");

            // Transforma em objeto Java
            List<Personagem> teste = transformerNodeList(listaPersonagens);

            System.out.println(teste);
        } catch (Exception e) {
            System.err.println("Erro");
            e.getMessage();
        }
    }

    private static List<Personagem> transformerNodeList(NodeList listaPersonagens) {
        List<Personagem> listaRetorno = new ArrayList<Personagem>();
        for (int i = 0; i < listaPersonagens.getLength(); i++) {
            Element personagem = (Element) listaPersonagens.item(i);
            listaRetorno.add(new Personagem(personagem.getFirstChild().getNodeValue()));
            System.out.println(personagem.getFirstChild().getNodeValue());
        }
        return listaRetorno;
    }

}
