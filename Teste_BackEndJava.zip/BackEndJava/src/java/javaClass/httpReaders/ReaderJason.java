package javaClass.httpReaders;

import javaClass.objects.Herois;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.codehaus.jackson.map.ObjectMapper;

/**
 *
 * @author felipe
 */

public class ReaderJason {

    public static void main(String[] args) {
        try {

            // Recebe a URL do JSOn
            Builder builder = ClientBuilder.newClient()
                    .target("https://raw.githubusercontent.com/uolhost/test-backEnd-Java/master/referencias/vingadores.json")
                    .request(MediaType.APPLICATION_JSON).header("Accept", "application/json");

            // Realiza a chamada HTTP
            Response response = builder.get();

            // Exception caso de erro de conexão/ retorno padrao HTTP é 200 caso haja sucesso
            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
            }

            // Recupera o corpo do json e realiza o cast para uma classe Java
            String retorno = response.readEntity(String.class);
            Herois herois = new ObjectMapper().readValue(retorno, Herois.class);

            System.out.println("Teste:" + herois.getVingadores().toString());

        } catch (Exception e) {

            e.printStackTrace();

        }
    }

}
